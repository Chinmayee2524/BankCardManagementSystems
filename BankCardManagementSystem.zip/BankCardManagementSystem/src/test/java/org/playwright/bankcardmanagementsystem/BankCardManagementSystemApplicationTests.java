package org.playwright.bankcardmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankCardManagementSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
